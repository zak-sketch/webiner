from waitress import serve
from cwebner.wsgi import application

serve(application, host='0.0.0.0', port=8080)
