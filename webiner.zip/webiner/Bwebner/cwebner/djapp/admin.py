from django.contrib import admin
from .models import Contact
from django.contrib.admin import AdminSite
# Register your models here.

admin.site.register(Contact)


class CustomAdminSite(AdminSite):
    site_header = 'Robotech Digital Administration'
    site_title = 'Robotech Digital Admin'
    index_title = 'Robotech Digital Admin Home'

admin_site = CustomAdminSite(name='customadmin')

# Register your models here using admin_site.register()

