from django.shortcuts import render
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from .forms import ContactForm
from django.contrib.admin.views.decorators import staff_member_required
from .forms import EmailForm
from django.core.mail import EmailMessage


def home(request):
    return render(request, 'home.html')

def services(request):
    return render(request, 'services.html')

def contacts(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            send_mail(
                subject=f"New Contact Form Submission: {subject}",
                message=f"Name: {name}\n\nEmail: {email}\n\nMessage: {message}",
                from_email='info@robotech.com',
                recipient_list=['robotechsoln@gmail.com'],
                fail_silently=False,
            )
            form.save()
            return redirect('home')  # Redirect to the home page after successful form submission
    
    else:
        form = ContactForm()
    return render(request, 'contacts.html', {'form': form})

def about(request):
    return render(request, 'about.html')
@staff_member_required  # Restrict access to only admin users
def private_view(request):
    if request.method == 'POST':
        form = EmailForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            recipient_list = [form.cleaned_data['email']]
            email = EmailMessage(
                subject=subject,
                body=message,
                from_email='info@robotech.com',
                to=recipient_list
            )
            # Send the email using the configured email backend
            email.send()
            return redirect('home')  # Redirect to a success page after sending email
    else:
        form = EmailForm()
    return render(request, 'private.html', {'form': form})




