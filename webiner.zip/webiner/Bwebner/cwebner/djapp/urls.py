from django.urls import path
from . import views
from .admin import admin_site





urlpatterns = [
    # other URL patterns here
    path('', views.home, name='home'),
    path('contacts', views.contacts, name='contacts'),
    path('about', views.about, name='about'),
    path('services', views.services, name='services'),
    path('private', views.private_view, name='private'),
    path('admin/', admin_site.urls),
]

