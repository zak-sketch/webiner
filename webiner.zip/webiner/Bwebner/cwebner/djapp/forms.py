from django import forms
from .models import Contact

class ContactForm(forms.ModelForm):
    email = forms.EmailField (
        label='Email',
        required=False,
        widget=forms.EmailInput(attrs={'placeholder': 'Please enter your Email'} )
    )

    name = forms.CharField(
        label='Name',
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Please Enter Both Names'})
            
    )

    subject = forms.CharField(
        label='Subject',
        required=True,
        widget=forms.TextInput(attrs={'placeholder': 'Please Enter a Subject'})
    )
    class Meta:
        model = Contact
        fields = ['name', 'email', 'subject', 'message']

class EmailForm(forms.Form):
    email = forms.EmailField(label='Email')
    subject = forms.CharField(label='Subject')
    message = forms.CharField(label='Message', widget=forms.Textarea)

